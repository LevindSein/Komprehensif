<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class No3Controller extends Controller
{
    //
}
