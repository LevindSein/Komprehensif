<?php $__env->startSection('body-content'); ?>
<h1 class="text-center">Komprehensif</h1>
<label>Soal :</label>
<div class="d-flex justify-content-center">
    <ol style="padding-left: 1rem;">
        <li class="text-sm">Buat program yang memiliki sequential search, branching, looping, array, dan fungsi.</li>
        <li class="text-sm">Buat program yang memiliki Logika Matematika, Teori Himpunan, Relasi dan Fungsi, Induksi Matematika, Graf, dan Pohon / Tree.</li>
        <li class="text-sm">Software Development Life Cycle</li>
    </ol>
</div>
<label>Pilih Jawaban :</label>
<div class="d-flex justify-content-center text-center">
    <div class="form-group">
        <a type="button" href="<?php echo e(url('jawaban/no-1')); ?>" class="btn btn-sm btn-outline-primary">Jawaban No.1 (Done)</a>
    </div>&nbsp;&nbsp;
    <div class="form-group">
        <a type="button" href="<?php echo e(url('jawaban/no-2')); ?>" class="btn btn-sm btn-outline-success disabled">Jawaban No.2</a>
    </div>&nbsp;&nbsp;
    <div class="form-group">
        <a type="button" href="<?php echo e(url('jawaban/no-3')); ?>" class="btn btn-sm btn-outline-danger disabled">Jawaban No.3</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\file\kompre\soal_1_dan_2\resources\views/welcome.blade.php ENDPATH**/ ?>